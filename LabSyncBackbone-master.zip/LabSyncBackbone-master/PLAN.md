# Plan: Option A (Cache Config) + Option B (Cache Unit Tests)

## Option A: Cache expiration from appsettings.json

Right now `InMemoryCacheService` has a hardcoded default of 300 seconds. We want to make it configurable — same pattern as `ExternalAppSettings`.

### Steps:

1. **Create `CacheSettings.cs`** in `AppSettings/`
   - One property: `ExpirationSeconds` (int)
   - Same simple class style as `ExternalAppSettings`

2. **Add config to `appsettings.json`**
   - Add a `"CacheSettings"` section with `"ExpirationSeconds": 300`

3. **Update `InMemoryCacheService` constructor**
   - Instead of taking a raw `int`, take `IOptions<CacheSettings>`
   - Read `ExpirationSeconds` from settings
   - This follows the same pattern `MockExternalAppClient` uses for `ExternalAppSettings`

4. **Update `Program.cs`**
   - Bind `CacheSettings` from config (like `ExternalAppSettings`)
   - Update the `InMemoryCacheService` registration to use DI properly

5. **Update tests** — tests create `InMemoryCacheService` directly, so they'll need to pass `IOptions<CacheSettings>` (using `Options.Create()`)

---

## Option B: Direct unit tests for InMemoryCacheService

We tested cache behavior *through* SyncService, but never tested the cache class itself. These tests verify the cache works correctly in isolation.

### Tests to write (new file: `Services/InMemoryCacheServiceTests.cs`):

1. **`Get_ShouldReturnNull_WhenKeyDoesNotExist`**
   - Call `Get` on an empty cache → should return `null`

2. **`Get_ShouldReturnResponse_WhenKeyExists`**
   - `Set` a response, then `Get` it → should return the same response

3. **`Set_ShouldOverwriteExistingEntry`**
   - `Set` two different responses with the same key → `Get` returns the second one

4. **`Get_ShouldReturnNull_WhenEntryIsExpired`**
   - Create cache with very short expiration (1 second)
   - `Set` a response, wait briefly, then `Get` → should return `null`

---

## Order of work:
1. Option A first (config) — since Option B tests will need to use the new constructor
2. Option B second (cache unit tests)
